<script setup>
import { ref, computed, watch } from 'vue';
import { useForm, usePage } from '@inertiajs/vue3';
import AdminLayout from '@/Layouts/AdminLayout.vue';
import ImageDropzone from '@/Components/Admin/ImageDropzone.vue';
import IconPicker from '@/Components/Admin/IconPicker.vue';
import Card from 'primevue/card';
import Button from 'primevue/button';
import InputText from 'primevue/inputtext';
import Textarea from 'primevue/textarea';
import Tabs from 'primevue/tabs';
import TabList from 'primevue/tablist';
import Tab from 'primevue/tab';
import Editor from 'primevue/editor';
import ToggleSwitch from 'primevue/toggleswitch';

const props = defineProps({
    settings: {
        type: Object,
        required: true,
    },
});

const page = usePage();
const languages = computed(() => page.props.languages);
const defaultLangCode = computed(() => languages.value.find((l) => l.is_default)?.code);

const emptyTranslatable = () => Object.fromEntries(languages.value.map((l) => [l.code, '']));

const normalizeInstituteInfo = (items) =>
    (items ?? []).map((item) => ({
        label: { ...emptyTranslatable(), ...item.label },
        value: { ...emptyTranslatable(), ...item.value },
    }));

// Footer link columns: label is translatable, url is a plain freeform
// string the admin types directly (not a route/model picker like the
// header's MenuItem) — these are just two flat footer columns, no submenus.
const normalizeFooterLinks = (items) =>
    (items ?? []).map((item) => ({
        label: { ...emptyTranslatable(), ...item.label },
        url: item.url ?? '',
    }));

// Default icon for newly-added repeater rows before the admin picks one —
// a generic Lucide icon, replaced via IconPicker (library search or upload).
const defaultIcon = () => ({ source: 'lucide', value: 'circle' });

const normalizeCtaStats = (items) =>
    (items ?? []).map((item) => ({
        icon: item.icon ?? defaultIcon(),
        value: item.value ?? '',
        label: { ...emptyTranslatable(), ...item.label },
    }));

const normalizePartnerLogos = (items) => (items ?? []).map((item) => ({ image: item.image ?? null }));

const normalizeChooseFeatures = (items) =>
    (items ?? []).map((item) => ({
        icon: item.icon ?? defaultIcon(),
        title: { ...emptyTranslatable(), ...item.title },
        description: { ...emptyTranslatable(), ...item.description },
    }));

const normalizeSkillItems = (items) =>
    (items ?? []).map((item) => ({
        label: { ...emptyTranslatable(), ...item.label },
        percentage: item.percentage ?? '',
    }));

const normalizeAboutItems = (items) =>
    (items ?? []).map((item) => ({
        icon: item.icon ?? defaultIcon(),
        title: { ...emptyTranslatable(), ...item.title },
        description: { ...emptyTranslatable(), ...item.description },
    }));

const sections = [
    { key: 'general', label: 'General', icon: 'pi pi-building', description: 'Site name, homepage layout template, and logos.' },
    { key: 'header', label: 'Header', icon: 'pi pi-align-left', description: "Address, phone, email, and social links shown in the site header — the footer reuses these too." },
    { key: 'footer', label: 'Footer', icon: 'pi pi-align-justify', description: "The footer's about text, copyright line, Quick Links / Our Campus columns, and Newsletter heading." },
    { key: 'sidebar', label: 'Homepage Sidebar', icon: 'pi pi-bars', description: 'Widgets, titles, photos, links, and show/hide options for the Home v2 sidebar.' },
    { key: 'school', label: 'School Profile', icon: 'pi pi-verified', description: 'Homepage stat strips: institute details under the slider, and the counter/CTA band further down.' },
    { key: 'choose', label: 'Why Choose Us', icon: 'pi pi-check-circle', description: 'The "Why Choose Us" block with feature boxes and a side image.', module: 'choose' },
    { key: 'about', label: 'About Us', icon: 'pi pi-info-circle', description: 'The "About Us" block with photos, an experience badge, feature items, and a quote.', module: 'about' },
    { key: 'skill', label: 'Our Skills', icon: 'pi pi-chart-bar', description: 'The enrollment card and "Our Skills" progress bars.', module: 'skill' },
    { key: 'video', label: 'Video Section', icon: 'pi pi-video', description: 'The "Latest Video" block further down the homepage.', module: 'video' },
    { key: 'offer', label: 'Offer Banner', icon: 'pi pi-megaphone', description: 'The promotional banner ("Our 20% Offer...") further down the homepage.', module: 'offer' },
    { key: 'principal', label: 'Our Principal', icon: 'pi pi-user', description: 'The current principal\'s photo, message, and the /principal page\'s breadcrumb & SEO.', module: 'principal' },
    { key: 'ex-principal', label: 'Ex-Principal', icon: 'pi pi-user-minus', description: 'The former principal\'s photo, message, and the /ex-principals page\'s breadcrumb & SEO.', module: 'ex_principal' },
    { key: 'contact', label: 'Contact Page', icon: 'pi pi-envelope', description: 'Office hours, the "Get In Touch" form intro/image/map, and the /contact page\'s breadcrumb & SEO.', module: 'contact' },
    { key: 'student-list', label: 'Student List', icon: 'pi pi-users', description: 'The /students page breadcrumb & SEO.' },
    { key: 'tuition-fees', label: 'Tuition Fees', icon: 'pi pi-wallet', description: 'The /tuition-fees page content, breadcrumb & SEO.' },
    { key: 'results', label: 'Result Pages', icon: 'pi pi-file-check', description: 'Breadcrumbs & SEO for Exam, Academic, Evaluation, and Board Exam Results pages.' },
];
// A tab with no `module` key always shows (General/Header/Footer/School
// aren't tied to any single Site Configuration toggle). Tabs tied to a
// module a developer disabled there disappear from here too, same as the
// sidebar — the fields underneath stay in the database either way, so
// re-enabling the module brings whatever was already entered right back.
const activeSectionKey = ref('general');
const activeSection = computed(() => sections.find((s) => s.key === activeSectionKey.value));

// One shared language tab across every section — picked once at the top of
// the content area, so every translatable field/card below (across every
// section) reads/writes `activeLang` directly instead of each needing its
// own <Tabs> language switcher.
const activeLang = ref('');
const currentLang = computed(() => languages.value.find((l) => l.code === activeLang.value));

const logoPreview = ref(props.settings.logo_url);
const footerLogoPreview = ref(props.settings.footer_logo_url);
const partnerLogoPreviews = ref(
    normalizePartnerLogos(props.settings.partner_logos).map((item) => (item.image ? `/storage/${item.image}` : null)),
);
const videoThumbnailPreview = ref(props.settings.video_thumbnail_url);
const offerBackgroundPreview = ref(props.settings.offer_background_url);
const chooseImagePreview = ref(props.settings.choose_image_url);
const aboutImage1Preview = ref(props.settings.about_image_1_url);
const aboutImage2Preview = ref(props.settings.about_image_2_url);
const aboutImage3Preview = ref(props.settings.about_image_3_url);
const aboutPageBreadcrumbPreview = ref(props.settings.about_page_breadcrumb_image_url);
const principalPhotoPreview = ref(props.settings.principal_photo_url);
const principalPageBreadcrumbPreview = ref(props.settings.principal_page_breadcrumb_image_url);
const exPrincipalPhotoPreview = ref(props.settings.ex_principal_photo_url);
const exPrincipalPageBreadcrumbPreview = ref(props.settings.ex_principal_page_breadcrumb_image_url);
const contactImagePreview = ref(props.settings.contact_image_url);
const contactPageBreadcrumbPreview = ref(props.settings.contact_page_breadcrumb_image_url);
const studentListPageBreadcrumbPreview = ref(props.settings.student_list_page_breadcrumb_image_url);
const tuitionFeePageBreadcrumbPreview = ref(props.settings.tuition_fee_page_breadcrumb_image_url);
const examResultPageBreadcrumbPreview = ref(props.settings.exam_result_page_breadcrumb_image_url);
const academicResultPageBreadcrumbPreview = ref(props.settings.academic_result_page_breadcrumb_image_url);
const evaluationResultPageBreadcrumbPreview = ref(props.settings.evaluation_result_page_breadcrumb_image_url);
const boardExamResultPageBreadcrumbPreview = ref(props.settings.board_exam_result_page_breadcrumb_image_url);
const sidebarMinisterPhotoPreview = ref(props.settings.sidebar_minister_photo_url);
const sidebarSecretaryPhotoPreview = ref(props.settings.sidebar_secretary_photo_url);
const sidebarVicePrincipalPhotoPreview = ref(props.settings.sidebar_vice_principal_photo_url);

const onImageSelected = (field, previewRef, file) => {
    form[field] = file;
    previewRef.value = URL.createObjectURL(file);
};

const onImageRemoved = (field, previewRef) => {
    form[field] = ''; // Send empty string to signal deletion
    previewRef.value = null;
};

const form = useForm({
    homepage_template: props.settings.homepage_template ?? 'default',
    logo: null,
    footer_logo: null,
    site_name: { ...emptyTranslatable(), ...props.settings.site_name },
    address: { ...emptyTranslatable(), ...props.settings.address },
    phone: props.settings.phone ?? '',
    email: props.settings.email ?? '',
    facebook_url: props.settings.facebook_url ?? '',
    instagram_url: props.settings.instagram_url ?? '',
    youtube_url: props.settings.youtube_url ?? '',
    whatsapp_url: props.settings.whatsapp_url ?? '',
    linkedin_url: props.settings.linkedin_url ?? '',
    footer_about: { ...emptyTranslatable(), ...props.settings.footer_about },
    copyright_text: { ...emptyTranslatable(), ...props.settings.copyright_text },
    footer_quick_links_title: { ...emptyTranslatable(), ...props.settings.footer_quick_links_title },
    footer_quick_links: normalizeFooterLinks(props.settings.footer_quick_links),
    footer_campus_title: { ...emptyTranslatable(), ...props.settings.footer_campus_title },
    footer_campus_links: normalizeFooterLinks(props.settings.footer_campus_links),
    footer_newsletter_title: { ...emptyTranslatable(), ...props.settings.footer_newsletter_title },
    footer_newsletter_text: { ...emptyTranslatable(), ...props.settings.footer_newsletter_text },
    institute_info: normalizeInstituteInfo(props.settings.institute_info),
    cta_stats: normalizeCtaStats(props.settings.cta_stats),
    partner_logos: normalizePartnerLogos(props.settings.partner_logos),
    video_thumbnail: null,
    video_tagline: { ...emptyTranslatable(), ...props.settings.video_tagline },
    video_title: { ...emptyTranslatable(), ...props.settings.video_title },
    video_highlight: { ...emptyTranslatable(), ...props.settings.video_highlight },
    video_description: { ...emptyTranslatable(), ...props.settings.video_description },
    video_button_text: { ...emptyTranslatable(), ...props.settings.video_button_text },
    video_button_url: props.settings.video_button_url ?? '',
    video_youtube_url: props.settings.video_youtube_url ?? '',
    offer_background: null,
    offer_title: { ...emptyTranslatable(), ...props.settings.offer_title },
    offer_description: { ...emptyTranslatable(), ...props.settings.offer_description },
    offer_button_text: { ...emptyTranslatable(), ...props.settings.offer_button_text },
    offer_button_url: props.settings.offer_button_url ?? '',
    choose_image: null,
    choose_tagline: { ...emptyTranslatable(), ...props.settings.choose_tagline },
    choose_title: { ...emptyTranslatable(), ...props.settings.choose_title },
    choose_highlight: { ...emptyTranslatable(), ...props.settings.choose_highlight },
    choose_description: { ...emptyTranslatable(), ...props.settings.choose_description },
    choose_features: normalizeChooseFeatures(props.settings.choose_features),
    skill_enroll_title: { ...emptyTranslatable(), ...props.settings.skill_enroll_title },
    skill_enroll_subtitle: { ...emptyTranslatable(), ...props.settings.skill_enroll_subtitle },
    skill_tagline: { ...emptyTranslatable(), ...props.settings.skill_tagline },
    skill_title: { ...emptyTranslatable(), ...props.settings.skill_title },
    skill_highlight: { ...emptyTranslatable(), ...props.settings.skill_highlight },
    skill_description: { ...emptyTranslatable(), ...props.settings.skill_description },
    skill_button_text: { ...emptyTranslatable(), ...props.settings.skill_button_text },
    skill_button_url: props.settings.skill_button_url ?? '',
    skill_items: normalizeSkillItems(props.settings.skill_items),
    about_image_1: null,
    about_image_2: null,
    about_image_3: null,
    about_tagline: { ...emptyTranslatable(), ...props.settings.about_tagline },
    about_title: { ...emptyTranslatable(), ...props.settings.about_title },
    about_highlight: { ...emptyTranslatable(), ...props.settings.about_highlight },
    about_description: { ...emptyTranslatable(), ...props.settings.about_description },
    about_quote: { ...emptyTranslatable(), ...props.settings.about_quote },
    about_button_text: { ...emptyTranslatable(), ...props.settings.about_button_text },
    about_button_url: props.settings.about_button_url ?? '',
    about_badge_icon: props.settings.about_badge_icon ?? defaultIcon(),
    about_badge_text: { ...emptyTranslatable(), ...props.settings.about_badge_text },
    about_items: normalizeAboutItems(props.settings.about_items),
    about_page_breadcrumb_image: null,
    about_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.about_page_breadcrumb_title },
    about_page_seo_title: { ...emptyTranslatable(), ...props.settings.about_page_seo_title },
    about_page_seo_description: { ...emptyTranslatable(), ...props.settings.about_page_seo_description },
    about_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.about_page_seo_keywords },
    principal_photo: null,
    principal_name: { ...emptyTranslatable(), ...props.settings.principal_name },
    principal_designation: { ...emptyTranslatable(), ...props.settings.principal_designation },
    principal_message: { ...emptyTranslatable(), ...props.settings.principal_message },
    principal_page_breadcrumb_image: null,
    principal_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.principal_page_breadcrumb_title },
    principal_page_seo_title: { ...emptyTranslatable(), ...props.settings.principal_page_seo_title },
    principal_page_seo_description: { ...emptyTranslatable(), ...props.settings.principal_page_seo_description },
    principal_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.principal_page_seo_keywords },
    ex_principal_photo: null,
    ex_principal_name: { ...emptyTranslatable(), ...props.settings.ex_principal_name },
    ex_principal_designation: { ...emptyTranslatable(), ...props.settings.ex_principal_designation },
    ex_principal_message: { ...emptyTranslatable(), ...props.settings.ex_principal_message },
    ex_principal_page_breadcrumb_image: null,
    ex_principal_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.ex_principal_page_breadcrumb_title },
    ex_principal_page_seo_title: { ...emptyTranslatable(), ...props.settings.ex_principal_page_seo_title },
    ex_principal_page_seo_description: { ...emptyTranslatable(), ...props.settings.ex_principal_page_seo_description },
    ex_principal_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.ex_principal_page_seo_keywords },
    student_list_page_breadcrumb_image: null,
    student_list_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.student_list_page_breadcrumb_title },
    student_list_page_seo_title: { ...emptyTranslatable(), ...props.settings.student_list_page_seo_title },
    student_list_page_seo_description: { ...emptyTranslatable(), ...props.settings.student_list_page_seo_description },
    student_list_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.student_list_page_seo_keywords },
    tuition_fee_page_breadcrumb_image: null,
    tuition_fee_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.tuition_fee_page_breadcrumb_title },
    tuition_fee_page_seo_title: { ...emptyTranslatable(), ...props.settings.tuition_fee_page_seo_title },
    tuition_fee_page_seo_description: { ...emptyTranslatable(), ...props.settings.tuition_fee_page_seo_description },
    tuition_fee_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.tuition_fee_page_seo_keywords },
    tuition_fee_page_content: { ...emptyTranslatable(), ...props.settings.tuition_fee_page_content },
    exam_result_page_breadcrumb_image: null,
    exam_result_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.exam_result_page_breadcrumb_title },
    exam_result_page_seo_title: { ...emptyTranslatable(), ...props.settings.exam_result_page_seo_title },
    exam_result_page_seo_description: { ...emptyTranslatable(), ...props.settings.exam_result_page_seo_description },
    exam_result_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.exam_result_page_seo_keywords },
    academic_result_page_breadcrumb_image: null,
    academic_result_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.academic_result_page_breadcrumb_title },
    academic_result_page_seo_title: { ...emptyTranslatable(), ...props.settings.academic_result_page_seo_title },
    academic_result_page_seo_description: { ...emptyTranslatable(), ...props.settings.academic_result_page_seo_description },
    academic_result_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.academic_result_page_seo_keywords },
    evaluation_result_page_breadcrumb_image: null,
    evaluation_result_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.evaluation_result_page_breadcrumb_title },
    evaluation_result_page_seo_title: { ...emptyTranslatable(), ...props.settings.evaluation_result_page_seo_title },
    evaluation_result_page_seo_description: { ...emptyTranslatable(), ...props.settings.evaluation_result_page_seo_description },
    evaluation_result_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.evaluation_result_page_seo_keywords },
    board_exam_result_page_breadcrumb_image: null,
    board_exam_result_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.board_exam_result_page_breadcrumb_title },
    board_exam_result_page_seo_title: { ...emptyTranslatable(), ...props.settings.board_exam_result_page_seo_title },
    board_exam_result_page_seo_description: { ...emptyTranslatable(), ...props.settings.board_exam_result_page_seo_description },
    board_exam_result_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.board_exam_result_page_seo_keywords },
    contact_address_label: { ...emptyTranslatable(), ...props.settings.contact_address_label },
    contact_address_value: { ...emptyTranslatable(), ...props.settings.contact_address_value },
    contact_phone_label: { ...emptyTranslatable(), ...props.settings.contact_phone_label },
    contact_phone_value: { ...emptyTranslatable(), ...props.settings.contact_phone_value },
    contact_email_label: { ...emptyTranslatable(), ...props.settings.contact_email_label },
    contact_email_value: { ...emptyTranslatable(), ...props.settings.contact_email_value },
    contact_open_time_label: { ...emptyTranslatable(), ...props.settings.contact_open_time_label },
    contact_open_time: { ...emptyTranslatable(), ...props.settings.contact_open_time },
    contact_form_title: { ...emptyTranslatable(), ...props.settings.contact_form_title },
    contact_form_description: { ...emptyTranslatable(), ...props.settings.contact_form_description },
    contact_image: null,
    contact_map_embed_url: props.settings.contact_map_embed_url ?? '',
    contact_page_breadcrumb_image: null,
    contact_page_breadcrumb_title: { ...emptyTranslatable(), ...props.settings.contact_page_breadcrumb_title },
    contact_page_seo_title: { ...emptyTranslatable(), ...props.settings.contact_page_seo_title },
    contact_page_seo_description: { ...emptyTranslatable(), ...props.settings.contact_page_seo_description },
    contact_page_seo_keywords: { ...emptyTranslatable(), ...props.settings.contact_page_seo_keywords },
    sidebar_notice_show: Boolean(props.settings.sidebar_notice_show ?? true),
    sidebar_notice_title: { ...emptyTranslatable(), ...props.settings.sidebar_notice_title },
    sidebar_notice_limit: props.settings.sidebar_notice_limit ?? 4,
    sidebar_minister_show: Boolean(props.settings.sidebar_minister_show ?? true),
    sidebar_minister_title: { ...emptyTranslatable(), ...props.settings.sidebar_minister_title },
    sidebar_minister_photo: null,
    sidebar_minister_name: { ...emptyTranslatable(), ...props.settings.sidebar_minister_name },
    sidebar_minister_role: { ...emptyTranslatable(), ...props.settings.sidebar_minister_role },
    sidebar_minister_button_text: { ...emptyTranslatable(), ...props.settings.sidebar_minister_button_text },
    sidebar_minister_button_url: props.settings.sidebar_minister_button_url ?? '',
    sidebar_secretary_show: Boolean(props.settings.sidebar_secretary_show ?? true),
    sidebar_secretary_title: { ...emptyTranslatable(), ...props.settings.sidebar_secretary_title },
    sidebar_secretary_photo: null,
    sidebar_secretary_name: { ...emptyTranslatable(), ...props.settings.sidebar_secretary_name },
    sidebar_secretary_role: { ...emptyTranslatable(), ...props.settings.sidebar_secretary_role },
    sidebar_secretary_button_text: { ...emptyTranslatable(), ...props.settings.sidebar_secretary_button_text },
    sidebar_secretary_button_url: props.settings.sidebar_secretary_button_url ?? '',
    sidebar_principal_show: Boolean(props.settings.sidebar_principal_show ?? true),
    sidebar_principal_title: { ...emptyTranslatable(), ...props.settings.sidebar_principal_title },
    sidebar_principal_button_text: { ...emptyTranslatable(), ...props.settings.sidebar_principal_button_text },
    sidebar_vice_principal_show: Boolean(props.settings.sidebar_vice_principal_show ?? true),
    sidebar_vice_principal_title: { ...emptyTranslatable(), ...props.settings.sidebar_vice_principal_title },
    sidebar_vice_principal_photo: null,
    sidebar_vice_principal_name: { ...emptyTranslatable(), ...props.settings.sidebar_vice_principal_name },
    sidebar_vice_principal_role: { ...emptyTranslatable(), ...props.settings.sidebar_vice_principal_role },
    sidebar_vice_principal_button_text: { ...emptyTranslatable(), ...props.settings.sidebar_vice_principal_button_text },
    sidebar_vice_principal_button_url: props.settings.sidebar_vice_principal_button_url ?? '',
    sidebar_calendar_show: Boolean(props.settings.sidebar_calendar_show ?? true),
    sidebar_calendar_title: { ...emptyTranslatable(), ...props.settings.sidebar_calendar_title },
});

const visibleSections = computed(() => {
    const enabledModules = page.props.enabledModules ?? [];

    return sections.filter((section) => {
        if (section.key === 'sidebar' && !['index-1', 'index-2'].includes(form.homepage_template)) {
            return false;
        }
        return !section.module || enabledModules.includes(section.module);
    });
});

watch(() => form.homepage_template, (newVal) => {
    if (newVal !== 'index-1' && activeSectionKey.value === 'sidebar') {
        activeSectionKey.value = 'general';
    }
});

activeLang.value = defaultLangCode.value;

const onLogoSelected = (file) => {
    form.logo = file;
    form.clearErrors('logo');
    logoPreview.value = URL.createObjectURL(file);
};
const onLogoRemoved = () => {
    form.logo = null;
    logoPreview.value = null;
};

const onFooterLogoSelected = (file) => {
    form.footer_logo = file;
    form.clearErrors('footer_logo');
    footerLogoPreview.value = URL.createObjectURL(file);
};
const onFooterLogoRemoved = () => {
    form.footer_logo = null;
    footerLogoPreview.value = null;
};

const addInstituteInfoItem = () => {
    form.institute_info.push({ label: emptyTranslatable(), value: emptyTranslatable() });
};
const removeInstituteInfoItem = (index) => {
    form.institute_info.splice(index, 1);
};

const addFooterQuickLink = () => {
    form.footer_quick_links.push({ label: emptyTranslatable(), url: '' });
};
const removeFooterQuickLink = (index) => {
    form.footer_quick_links.splice(index, 1);
};

const addFooterCampusLink = () => {
    form.footer_campus_links.push({ label: emptyTranslatable(), url: '' });
};
const removeFooterCampusLink = (index) => {
    form.footer_campus_links.splice(index, 1);
};

const addCtaStatItem = () => {
    form.cta_stats.push({ icon: defaultIcon(), value: '', label: emptyTranslatable() });
};
const removeCtaStatItem = (index) => {
    form.cta_stats.splice(index, 1);
};

const addPartnerLogo = () => {
    form.partner_logos.push({ image: null });
    partnerLogoPreviews.value.push(null);
};
const removePartnerLogo = (index) => {
    form.partner_logos.splice(index, 1);
    partnerLogoPreviews.value.splice(index, 1);
};
const onPartnerLogoSelected = (index, file) => {
    form.partner_logos[index].image = file;
    form.clearErrors(`partner_logos.${index}.image`);
    partnerLogoPreviews.value[index] = URL.createObjectURL(file);
};
const onPartnerLogoRemovedImage = (index) => {
    form.partner_logos[index].image = null;
    partnerLogoPreviews.value[index] = null;
};

const onVideoThumbnailSelected = (file) => {
    form.video_thumbnail = file;
    form.clearErrors('video_thumbnail');
    videoThumbnailPreview.value = URL.createObjectURL(file);
};
const onVideoThumbnailRemoved = () => {
    form.video_thumbnail = null;
    videoThumbnailPreview.value = null;
};

const onOfferBackgroundSelected = (file) => {
    form.offer_background = file;
    form.clearErrors('offer_background');
    offerBackgroundPreview.value = URL.createObjectURL(file);
};
const onOfferBackgroundRemoved = () => {
    form.offer_background = null;
    offerBackgroundPreview.value = null;
};

const onChooseImageSelected = (file) => {
    form.choose_image = file;
    form.clearErrors('choose_image');
    chooseImagePreview.value = URL.createObjectURL(file);
};
const onChooseImageRemoved = () => {
    form.choose_image = null;
    chooseImagePreview.value = null;
};

const addChooseFeature = () => {
    form.choose_features.push({ icon: defaultIcon(), title: emptyTranslatable(), description: emptyTranslatable() });
};
const removeChooseFeature = (index) => {
    form.choose_features.splice(index, 1);
};

const addSkillItem = () => {
    form.skill_items.push({ label: emptyTranslatable(), percentage: '' });
};
const removeSkillItem = (index) => {
    form.skill_items.splice(index, 1);
};

const onAboutImageSelected = (field, previewRef, file) => {
    form[field] = file;
    form.clearErrors(field);
    previewRef.value = URL.createObjectURL(file);
};
const onAboutImageRemoved = (field, previewRef) => {
    form[field] = null;
    previewRef.value = null;
};

const addAboutItem = () => {
    form.about_items.push({ icon: defaultIcon(), title: emptyTranslatable(), description: emptyTranslatable() });
};
const removeAboutItem = (index) => {
    form.about_items.splice(index, 1);
};

const onSidebarMinisterPhotoSelected = (file) => {
    form.sidebar_minister_photo = file;
    form.clearErrors('sidebar_minister_photo');
    sidebarMinisterPhotoPreview.value = URL.createObjectURL(file);
};
const onSidebarMinisterPhotoRemoved = () => {
    form.sidebar_minister_photo = null;
    sidebarMinisterPhotoPreview.value = null;
};

const onSidebarSecretaryPhotoSelected = (file) => {
    form.sidebar_secretary_photo = file;
    form.clearErrors('sidebar_secretary_photo');
    sidebarSecretaryPhotoPreview.value = URL.createObjectURL(file);
};
const onSidebarSecretaryPhotoRemoved = () => {
    form.sidebar_secretary_photo = null;
    sidebarSecretaryPhotoPreview.value = null;
};

const onSidebarVicePrincipalPhotoSelected = (file) => {
    form.sidebar_vice_principal_photo = file;
    form.clearErrors('sidebar_vice_principal_photo');
    sidebarVicePrincipalPhotoPreview.value = URL.createObjectURL(file);
};
const onSidebarVicePrincipalPhotoRemoved = () => {
    form.sidebar_vice_principal_photo = null;
    sidebarVicePrincipalPhotoPreview.value = null;
};

const submit = () => {
    form.transform((data) => ({ ...data, _method: 'put' })).post(route('admin.settings.website.update'), {
        forceFormData: true,
        preserveScroll: true,
    });
};
</script>

<template>
    <AdminLayout title="Website Options">
        <p class="text-sm text-slate-500 mb-6">
            Global content shown across the public site's header and footer.
        </p>

        <div class="flex flex-col md:flex-row gap-6 items-start">
            <!-- section nav -->
            <nav class="w-full md:w-60 shrink-0 md:sticky md:top-6">
                <div class="flex md:flex-col gap-1 overflow-x-auto md:overflow-visible rounded-xl border border-slate-200 bg-white p-1.5 shadow-sm">
                    <button
                        v-for="section in visibleSections"
                        :key="section.key"
                        type="button"
                        class="group flex items-center gap-3 rounded-lg px-3.5 py-2.5 text-sm text-left whitespace-nowrap transition-colors w-full"
                        :class="activeSectionKey === section.key
                            ? 'bg-indigo-600 text-white shadow-sm'
                            : 'text-slate-600 hover:bg-slate-100'"
                        @click="activeSectionKey = section.key"
                    >
                        <i
                            :class="[section.icon, activeSectionKey === section.key ? 'text-white' : 'text-slate-400 group-hover:text-slate-500']"
                            class="text-base"
                        />
                        <span class="flex-1 font-medium">{{ section.label }}</span>
                    </button>
                </div>
            </nav>

            <!-- section content -->
            <Card class="w-full flex-1 shadow-sm">
                <template #content>
                    <p class="text-sm text-slate-500 mb-6">{{ activeSection?.description }}</p>

                    <!-- language switcher, shared by every translatable field/card below -->
                    <div class="mb-6 pb-5 border-b border-slate-100">
                        <Tabs v-model:value="activeLang">
                            <TabList>
                                <Tab v-for="lang in languages" :key="lang.code" :value="lang.code">{{ lang.native_name }}</Tab>
                            </TabList>
                        </Tabs>
                    </div>

                    <!-- General -->
                    <div v-show="activeSectionKey === 'general'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-1">Homepage Layout Template</h3>
                            <p class="text-xs text-slate-500 mb-4">Choose which layout template version to display on the public website home page.</p>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl">
                                <label
                                    class="relative flex flex-col p-4 cursor-pointer rounded-xl border-2 transition-all"
                                    :class="form.homepage_template === 'default' ? 'border-indigo-600 bg-indigo-50/30' : 'border-slate-200 hover:border-slate-300'"
                                >
                                    <div class="flex items-center justify-between mb-2">
                                        <div class="flex items-center gap-2 font-semibold text-sm text-slate-800">
                                            <i class="pi pi-desktop text-indigo-600" />
                                            <span>Default Layout (Home v1)</span>
                                        </div>
                                        <input type="radio" v-model="form.homepage_template" value="default" class="text-indigo-600 focus:ring-indigo-500" />
                                    </div>
                                    <p class="text-xs text-slate-500">Standard full-width sections layout across the homepage.</p>
                                </label>

                                <label
                                    class="relative flex flex-col p-4 cursor-pointer rounded-xl border-2 transition-all"
                                    :class="form.homepage_template === 'index-1' ? 'border-indigo-600 bg-indigo-50/30' : 'border-slate-200 hover:border-slate-300'"
                                >
                                    <div class="flex items-center justify-between mb-2">
                                        <div class="flex items-center gap-2 font-semibold text-sm text-slate-800">
                                            <i class="pi pi-bars text-indigo-600" />
                                            <span>Sidebar Layout (Home v2)</span>
                                        </div>
                                        <input type="radio" v-model="form.homepage_template" value="index-1" class="text-indigo-600 focus:ring-indigo-500" />
                                    </div>
                                    <p class="text-xs text-slate-500">Layout with right sidebar (Notices, Principal message, Calendar, Minister card).</p>
                                </label>

                                <label
                                    class="relative flex flex-col p-4 cursor-pointer rounded-xl border-2 transition-all"
                                    :class="form.homepage_template === 'index-2' ? 'border-indigo-600 bg-indigo-50/30' : 'border-slate-200 hover:border-slate-300'"
                                >
                                    <div class="flex items-center justify-between mb-2">
                                        <div class="flex items-center gap-2 font-semibold text-sm text-slate-800">
                                            <i class="pi pi-th-large text-indigo-600" />
                                            <span>Grid Layout (Home v3)</span>
                                        </div>
                                        <input type="radio" v-model="form.homepage_template" value="index-2" class="text-indigo-600 focus:ring-indigo-500" />
                                    </div>
                                    <p class="text-xs text-slate-500">Layout with full-width widget grid between counters and courses.</p>
                                </label>
                            </div>
                            <p v-if="form.errors.homepage_template" class="text-xs text-red-500 mt-2">{{ form.errors.homepage_template }}</p>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Site name</h3>
                            <div class="max-w-md">
                                <InputText
                                    v-model="form.site_name[activeLang]"
                                    :dir="currentLang?.direction"
                                    class="w-full"
                                    :placeholder="currentLang?.is_default ? 'Required' : 'Optional'"
                                />
                                <p v-if="form.errors[`site_name.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`site_name.${activeLang}`] }}</p>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Logos</h3>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Header logo</label>
                                    <ImageDropzone
                                        :preview-url="logoPreview"
                                        hint="Drag & drop a logo, or click to browse"
                                        width-class="w-full sm:w-64" height-class="h-32"
                                        @select="onLogoSelected"
                                        @remove="onLogoRemoved"
                                    />
                                    <p v-if="form.errors.logo" class="text-xs text-red-500 mt-1">{{ form.errors.logo }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Footer logo</label>
                                    <ImageDropzone
                                        :preview-url="footerLogoPreview"
                                        hint="Optional — falls back to header logo"
                                        width-class="w-full sm:w-64" height-class="h-32"
                                        @select="onFooterLogoSelected"
                                        @remove="onFooterLogoRemoved"
                                    />
                                    <p v-if="form.errors.footer_logo" class="text-xs text-red-500 mt-1">{{ form.errors.footer_logo }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Homepage Sidebar -->
                    <div v-show="activeSectionKey === 'sidebar'" class="flex flex-col gap-5">
                        <div class="rounded-xl border border-indigo-100 bg-indigo-50/40 p-4 text-sm text-indigo-900 flex items-center gap-3">
                            <i class="pi pi-info-circle text-indigo-600 text-lg shrink-0" />
                            <span>These options manage all widgets displayed in the right sidebar when <strong>Home v2 (Sidebar Layout)</strong> is selected.</span>
                        </div>

                        <!-- Notice Board Widget -->
                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                                <div>
                                    <h3 class="text-sm font-semibold text-slate-800">Notice Board Widget</h3>
                                    <p class="text-xs text-slate-400">Sidebar notice board displaying active site notices.</p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-medium text-slate-600">{{ form.sidebar_notice_show ? 'Visible' : 'Hidden' }}</span>
                                    <ToggleSwitch v-model="form.sidebar_notice_show" />
                                </div>
                            </div>
                            <div v-show="form.sidebar_notice_show" class="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Widget Title</label>
                                    <InputText v-model="form.sidebar_notice_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Notice Board" />
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Max Notices Limit</label>
                                    <InputText v-model.number="form.sidebar_notice_limit" type="number" min="1" max="20" class="w-full" placeholder="4" />
                                </div>
                            </div>
                        </section>

                        <!-- Hon'ble Minister Widget -->
                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                                <div>
                                    <h3 class="text-sm font-semibold text-slate-800">Hon'ble Minister Widget</h3>
                                    <p class="text-xs text-slate-400">Featured card for the Education Minister.</p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-medium text-slate-600">{{ form.sidebar_minister_show ? 'Visible' : 'Hidden' }}</span>
                                    <ToggleSwitch v-model="form.sidebar_minister_show" />
                                </div>
                            </div>
                            <div v-show="form.sidebar_minister_show" class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Widget Title</label>
                                    <InputText v-model="form.sidebar_minister_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Hon'ble Minister" />
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Photo</label>
                                    <ImageDropzone
                                        :preview-url="sidebarMinisterPhotoPreview"
                                        hint="Drag & drop a photo, or click to browse"
                                        width-class="w-full sm:w-64" height-class="h-32"
                                        @select="onSidebarMinisterPhotoSelected"
                                        @remove="onSidebarMinisterPhotoRemoved"
                                    />
                                    <p v-if="form.errors.sidebar_minister_photo" class="text-xs text-red-500 mt-1">{{ form.errors.sidebar_minister_photo }}</p>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Name</label>
                                        <InputText v-model="form.sidebar_minister_name[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Dr. A N M Ehsanul Hoque Milon" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Designation / Role</label>
                                        <InputText v-model="form.sidebar_minister_role[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Hon'ble Minister, Ministry of Education" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button Text</label>
                                        <InputText v-model="form.sidebar_minister_button_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="See More" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button URL</label>
                                        <InputText v-model="form.sidebar_minister_button_url" class="w-full" placeholder="https://..." />
                                    </div>
                                </div>
                            </div>
                        </section>

                        <!-- Secretary Widget -->
                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                                <div>
                                    <h3 class="text-sm font-semibold text-slate-800">Secretary Widget</h3>
                                    <p class="text-xs text-slate-400">Featured card for the Education Secretary.</p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-medium text-slate-600">{{ form.sidebar_secretary_show ? 'Visible' : 'Hidden' }}</span>
                                    <ToggleSwitch v-model="form.sidebar_secretary_show" />
                                </div>
                            </div>
                            <div v-show="form.sidebar_secretary_show" class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Widget Title</label>
                                    <InputText v-model="form.sidebar_secretary_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Secretary" />
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Photo</label>
                                    <ImageDropzone
                                        :preview-url="sidebarSecretaryPhotoPreview"
                                        hint="Drag & drop a photo, or click to browse"
                                        width-class="w-full sm:w-64" height-class="h-32"
                                        @select="onSidebarSecretaryPhotoSelected"
                                        @remove="onSidebarSecretaryPhotoRemoved"
                                    />
                                    <p v-if="form.errors.sidebar_secretary_photo" class="text-xs text-red-500 mt-1">{{ form.errors.sidebar_secretary_photo }}</p>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Name</label>
                                        <InputText v-model="form.sidebar_secretary_name[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Abdul Khaleque" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Designation / Role</label>
                                        <InputText v-model="form.sidebar_secretary_role[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Secretary, Secondary & Higher Education Division" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button Text</label>
                                        <InputText v-model="form.sidebar_secretary_button_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="See More" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button URL</label>
                                        <InputText v-model="form.sidebar_secretary_button_url" class="w-full" placeholder="https://..." />
                                    </div>
                                </div>
                            </div>
                        </section>

                        <!-- Our Principal Widget -->
                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                                <div>
                                    <h3 class="text-sm font-semibold text-slate-800">Our Principal Widget</h3>
                                    <p class="text-xs text-slate-400">Featured card for Principal (photo/name/role are set in Our Principal tab).</p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-medium text-slate-600">{{ form.sidebar_principal_show ? 'Visible' : 'Hidden' }}</span>
                                    <ToggleSwitch v-model="form.sidebar_principal_show" />
                                </div>
                            </div>
                            <div v-show="form.sidebar_principal_show" class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Widget Title</label>
                                    <InputText v-model="form.sidebar_principal_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Our Principal" />
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Button Text</label>
                                    <InputText v-model="form.sidebar_principal_button_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Read More" />
                                </div>
                            </div>
                        </section>

                        <!-- Our Vice Principal Widget -->
                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                                <div>
                                    <h3 class="text-sm font-semibold text-slate-800">Our Vice Principal Widget</h3>
                                    <p class="text-xs text-slate-400">Featured card for the Vice Principal.</p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-medium text-slate-600">{{ form.sidebar_vice_principal_show ? 'Visible' : 'Hidden' }}</span>
                                    <ToggleSwitch v-model="form.sidebar_vice_principal_show" />
                                </div>
                            </div>
                            <div v-show="form.sidebar_vice_principal_show" class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Widget Title</label>
                                    <InputText v-model="form.sidebar_vice_principal_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Our Vice Principal" />
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Photo</label>
                                    <ImageDropzone
                                        :preview-url="sidebarVicePrincipalPhotoPreview"
                                        hint="Drag & drop a photo, or click to browse"
                                        width-class="w-full sm:w-64" height-class="h-32"
                                        @select="onSidebarVicePrincipalPhotoSelected"
                                        @remove="onSidebarVicePrincipalPhotoRemoved"
                                    />
                                    <p v-if="form.errors.sidebar_vice_principal_photo" class="text-xs text-red-500 mt-1">{{ form.errors.sidebar_vice_principal_photo }}</p>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Name</label>
                                        <InputText v-model="form.sidebar_vice_principal_name[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Dennis A. Pruitt" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Designation / Role</label>
                                        <InputText v-model="form.sidebar_vice_principal_role[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Vice Principal" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button Text</label>
                                        <InputText v-model="form.sidebar_vice_principal_button_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Read More" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button URL</label>
                                        <InputText v-model="form.sidebar_vice_principal_button_url" class="w-full" placeholder="https://..." />
                                    </div>
                                </div>
                            </div>
                        </section>

                        <!-- Academic Calendar Widget -->
                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                                <div>
                                    <h3 class="text-sm font-semibold text-slate-800">Academic Calendar Widget</h3>
                                    <p class="text-xs text-slate-400">Monthly calendar widget showing today & upcoming events.</p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-medium text-slate-600">{{ form.sidebar_calendar_show ? 'Visible' : 'Hidden' }}</span>
                                    <ToggleSwitch v-model="form.sidebar_calendar_show" />
                                </div>
                            </div>
                            <div v-show="form.sidebar_calendar_show" class="max-w-xs">
                                <label class="block text-xs font-medium text-slate-600 mb-1.5">Widget Title</label>
                                <InputText v-model="form.sidebar_calendar_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Academic Calendar" />
                            </div>
                        </section>
                    </div>

                    <!-- Header (contact + social) -->
                    <div v-show="activeSectionKey === 'header'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Address</h3>
                            <div class="max-w-md">
                                <InputText v-model="form.address[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="City, Country" />
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Contact details</h3>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Phone</label>
                                    <InputText v-model="form.phone" class="w-full" placeholder="+880 1712-345678" />
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Email</label>
                                    <InputText v-model="form.email" class="w-full" placeholder="info@example.com" />
                                    <p v-if="form.errors.email" class="text-xs text-red-500 mt-1">{{ form.errors.email }}</p>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Social links</h3>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5"><i class="pi pi-facebook mr-1" />Facebook</label>
                                    <InputText v-model="form.facebook_url" class="w-full" placeholder="https://facebook.com/..." />
                                    <p v-if="form.errors.facebook_url" class="text-xs text-red-500 mt-1">{{ form.errors.facebook_url }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5"><i class="pi pi-instagram mr-1" />Instagram</label>
                                    <InputText v-model="form.instagram_url" class="w-full" placeholder="https://instagram.com/..." />
                                    <p v-if="form.errors.instagram_url" class="text-xs text-red-500 mt-1">{{ form.errors.instagram_url }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5"><i class="pi pi-youtube mr-1" />YouTube</label>
                                    <InputText v-model="form.youtube_url" class="w-full" placeholder="https://youtube.com/..." />
                                    <p v-if="form.errors.youtube_url" class="text-xs text-red-500 mt-1">{{ form.errors.youtube_url }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5"><i class="pi pi-whatsapp mr-1" />WhatsApp</label>
                                    <InputText v-model="form.whatsapp_url" class="w-full" placeholder="https://wa.me/..." />
                                    <p v-if="form.errors.whatsapp_url" class="text-xs text-red-500 mt-1">{{ form.errors.whatsapp_url }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5"><i class="pi pi-linkedin mr-1" />LinkedIn</label>
                                    <InputText v-model="form.linkedin_url" class="w-full" placeholder="https://linkedin.com/..." />
                                    <p v-if="form.errors.linkedin_url" class="text-xs text-red-500 mt-1">{{ form.errors.linkedin_url }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Footer -->
                    <div v-show="activeSectionKey === 'footer'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">About text &amp; copyright</h3>
                            <div class="max-w-lg">
                                <div class="flex flex-col gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1">About text</label>
                                        <Textarea v-model="form.footer_about[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1">Copyright line</label>
                                        <InputText v-model="form.copyright_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="All Rights Reserved." />
                                    </div>
                                </div>
                                <p class="text-xs text-slate-400 mt-3">
                                    Copyright line is shown at the end, e.g. "© 2026 {{ form.site_name[defaultLangCode] || 'Your School' }} — {{ form.copyright_text[defaultLangCode] || 'All Rights Reserved.' }}"
                                </p>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-3">
                                <div>
                                    <h3 class="text-sm font-semibold text-slate-800">Quick Links column</h3>
                                    <p class="text-xs text-slate-400 mt-0.5">Column heading and its list of links.</p>
                                </div>
                                <Button label="Add link" icon="pi pi-plus" text size="small" @click="addFooterQuickLink" />
                            </div>

                            <div class="max-w-sm mb-4">
                                <label class="block text-xs font-medium text-slate-600 mb-1.5">Column heading</label>
                                <InputText v-model="form.footer_quick_links_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Quick Links" />
                            </div>

                            <p v-if="!form.footer_quick_links.length" class="text-sm text-slate-400">No links yet — add one above.</p>
                            <div v-else class="flex flex-col gap-3">
                                <div
                                    v-for="(item, index) in form.footer_quick_links"
                                    :key="index"
                                    class="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 sm:items-start rounded-lg border border-slate-100 p-3"
                                >
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Label</label>
                                        <InputText
                                            v-model="item.label[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required, e.g. About Us' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`footer_quick_links.${index}.label.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`footer_quick_links.${index}.label.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">URL</label>
                                        <InputText v-model="item.url" class="w-full" placeholder="/about or https://..." />
                                        <p v-if="form.errors[`footer_quick_links.${index}.url`]" class="text-xs text-red-500 mt-1">{{ form.errors[`footer_quick_links.${index}.url`] }}</p>
                                    </div>
                                    <div class="flex sm:items-end sm:justify-end">
                                        <Button icon="pi pi-trash" text rounded severity="danger" @click="removeFooterQuickLink(index)" />
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-3">
                                <div>
                                    <h3 class="text-sm font-semibold text-slate-800">Our Campus column</h3>
                                    <p class="text-xs text-slate-400 mt-0.5">Column heading and its list of links.</p>
                                </div>
                                <Button label="Add link" icon="pi pi-plus" text size="small" @click="addFooterCampusLink" />
                            </div>

                            <div class="max-w-sm mb-4">
                                <label class="block text-xs font-medium text-slate-600 mb-1.5">Column heading</label>
                                <InputText v-model="form.footer_campus_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Our Campus" />
                            </div>

                            <p v-if="!form.footer_campus_links.length" class="text-sm text-slate-400">No links yet — add one above.</p>
                            <div v-else class="flex flex-col gap-3">
                                <div
                                    v-for="(item, index) in form.footer_campus_links"
                                    :key="index"
                                    class="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 sm:items-start rounded-lg border border-slate-100 p-3"
                                >
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Label</label>
                                        <InputText
                                            v-model="item.label[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required, e.g. Campus Safety' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`footer_campus_links.${index}.label.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`footer_campus_links.${index}.label.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">URL</label>
                                        <InputText v-model="item.url" class="w-full" placeholder="/about or https://..." />
                                        <p v-if="form.errors[`footer_campus_links.${index}.url`]" class="text-xs text-red-500 mt-1">{{ form.errors[`footer_campus_links.${index}.url`] }}</p>
                                    </div>
                                    <div class="flex sm:items-end sm:justify-end">
                                        <Button icon="pi pi-trash" text rounded severity="danger" @click="removeFooterCampusLink(index)" />
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Newsletter column</h3>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Column heading</label>
                                    <InputText v-model="form.footer_newsletter_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="Newsletter" />
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Description text</label>
                                    <Textarea v-model="form.footer_newsletter_text[activeLang]" :dir="currentLang?.direction" rows="2" class="w-full" placeholder="Subscribe Our Newsletter To Get Latest Update And News" />
                                </div>
                            </div>
                            <p class="text-xs text-slate-400 mt-3">
                                The subscribe form itself isn't wired up to anything yet — only this heading and description are editable here.
                            </p>
                        </section>
                    </div>

                    <!-- School Profile -->
                    <div v-show="activeSectionKey === 'school'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-3">
                                <h3 class="text-sm font-semibold text-slate-800">Institute details</h3>
                                <Button label="Add item" icon="pi pi-plus" text size="small" @click="addInstituteInfoItem" />
                            </div>

                            <p v-if="!form.institute_info.length" class="text-sm text-slate-400">No items yet — add one above.</p>
                            <div v-else class="flex flex-col gap-3">
                                <div
                                    v-for="(item, index) in form.institute_info"
                                    :key="index"
                                    class="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 sm:items-start rounded-lg border border-slate-100 p-3"
                                >
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Label</label>
                                        <InputText
                                            v-model="item.label[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required, e.g. Institute EIIN' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`institute_info.${index}.label.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`institute_info.${index}.label.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Value</label>
                                        <InputText
                                            v-model="item.value[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required, e.g. 123456' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`institute_info.${index}.value.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`institute_info.${index}.value.${activeLang}`] }}</p>
                                    </div>
                                    <div class="flex sm:justify-end sm:pt-6">
                                        <Button icon="pi pi-trash" text severity="danger" aria-label="Remove item" @click="removeInstituteInfoItem(index)" />
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-3">
                                <h3 class="text-sm font-semibold text-slate-800">CTA section</h3>
                                <Button label="Add item" icon="pi pi-plus" text size="small" @click="addCtaStatItem" />
                            </div>
                            <p class="text-xs text-slate-400 mb-3">The counter strip shown further down the homepage (icon, number, and label — e.g. "500 + Total Courses").</p>

                            <p v-if="!form.cta_stats.length" class="text-sm text-slate-400">No items yet — add one above.</p>
                            <div v-else class="flex flex-col gap-3">
                                <div
                                    v-for="(item, index) in form.cta_stats"
                                    :key="index"
                                    class="grid grid-cols-1 sm:grid-cols-[auto_auto_1fr_auto] gap-3 sm:items-start rounded-lg border border-slate-100 p-3"
                                >
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Icon</label>
                                        <IconPicker v-model="item.icon" />
                                        <p v-if="form.errors[`cta_stats.${index}.icon.value`]" class="text-xs text-red-500 mt-1">{{ form.errors[`cta_stats.${index}.icon.value`] }}</p>
                                    </div>
                                    <div class="sm:w-28">
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Number</label>
                                        <InputText v-model="item.value" class="w-full" placeholder="500" />
                                        <p v-if="form.errors[`cta_stats.${index}.value`]" class="text-xs text-red-500 mt-1">{{ form.errors[`cta_stats.${index}.value`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Label</label>
                                        <InputText
                                            v-model="item.label[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required, e.g. Total Courses' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`cta_stats.${index}.label.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`cta_stats.${index}.label.${activeLang}`] }}</p>
                                    </div>
                                    <div class="flex sm:justify-end sm:pt-6">
                                        <Button icon="pi pi-trash" text severity="danger" aria-label="Remove item" @click="removeCtaStatItem(index)" />
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-3">
                                <h3 class="text-sm font-semibold text-slate-800">Partner logos</h3>
                                <Button label="Add logo" icon="pi pi-plus" text size="small" @click="addPartnerLogo" />
                            </div>
                            <p class="text-xs text-slate-400 mb-3">Logo strip shown near the footer.</p>

                            <p v-if="!form.partner_logos.length" class="text-sm text-slate-400">No logos yet — add one above.</p>
                            <div v-else class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                                <div v-for="(_, index) in form.partner_logos" :key="index" class="relative">
                                    <button
                                        type="button"
                                        class="absolute -top-2 -right-2 z-10 size-6 rounded-full bg-white border border-slate-200 shadow flex items-center justify-center text-red-500 hover:bg-red-50"
                                        aria-label="Remove logo"
                                        @click="removePartnerLogo(index)"
                                    >
                                        <i class="pi pi-times text-xs" />
                                    </button>
                                    <ImageDropzone
                                        :preview-url="partnerLogoPreviews[index]"
                                        hint="Logo"
                                        width-class="w-full" height-class="h-24"
                                        @select="(file) => onPartnerLogoSelected(index, file)"
                                        @remove="() => onPartnerLogoRemovedImage(index)"
                                    />
                                    <p v-if="form.errors[`partner_logos.${index}.image`]" class="text-xs text-red-500 mt-1">{{ form.errors[`partner_logos.${index}.image`] }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Why Choose Us -->
                    <div v-show="activeSectionKey === 'choose'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Content</h3>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Tagline</label>
                                    <InputText v-model="form.choose_tagline[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Why Choose Us" />
                                    <p v-if="form.errors[`choose_tagline.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`choose_tagline.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Title</label>
                                    <InputText v-model="form.choose_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. We Are Expert & Do Our Best For Your Goal" />
                                    <p v-if="form.errors[`choose_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`choose_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Highlighted words</label>
                                    <InputText v-model="form.choose_highlight[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Do Our Best" />
                                    <p class="text-xs text-slate-400 mt-1">The words within Title to show in orange — must match exactly.</p>
                                    <p v-if="form.errors[`choose_highlight.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`choose_highlight.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
                                    <Textarea v-model="form.choose_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`choose_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`choose_description.${activeLang}`] }}</p>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Side image</h3>
                            <div class="max-w-xs">
                                <ImageDropzone
                                    :preview-url="chooseImagePreview"
                                    hint="Photo shown next to the feature boxes"
                                    width-class="w-full" height-class="h-32"
                                    @select="onChooseImageSelected"
                                    @remove="onChooseImageRemoved"
                                />
                                <p v-if="form.errors.choose_image" class="text-xs text-red-500 mt-1">{{ form.errors.choose_image }}</p>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-3">
                                <h3 class="text-sm font-semibold text-slate-800">Feature boxes</h3>
                                <Button label="Add item" icon="pi pi-plus" text size="small" @click="addChooseFeature" />
                            </div>

                            <p v-if="!form.choose_features.length" class="text-sm text-slate-400">No items yet — add one above.</p>
                            <div v-else class="flex flex-col gap-3">
                                <div
                                    v-for="(item, index) in form.choose_features"
                                    :key="index"
                                    class="grid grid-cols-1 sm:grid-cols-[auto_1fr_1fr_auto] gap-3 sm:items-start rounded-lg border border-slate-100 p-3"
                                >
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Icon</label>
                                        <IconPicker v-model="item.icon" />
                                        <p v-if="form.errors[`choose_features.${index}.icon.value`]" class="text-xs text-red-500 mt-1">{{ form.errors[`choose_features.${index}.icon.value`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Title</label>
                                        <InputText
                                            v-model="item.title[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required, e.g. Expert Teachers' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`choose_features.${index}.title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`choose_features.${index}.title.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
                                        <InputText
                                            v-model="item.description[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`choose_features.${index}.description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`choose_features.${index}.description.${activeLang}`] }}</p>
                                    </div>
                                    <div class="flex sm:justify-end sm:pt-6">
                                        <Button icon="pi pi-trash" text severity="danger" aria-label="Remove item" @click="removeChooseFeature(index)" />
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- About Us -->
                    <div v-show="activeSectionKey === 'about'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Content</h3>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Tagline</label>
                                    <InputText v-model="form.about_tagline[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. About Us" />
                                    <p v-if="form.errors[`about_tagline.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_tagline.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Title</label>
                                    <InputText v-model="form.about_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Our WexNix Tion System Inspires You More." />
                                    <p v-if="form.errors[`about_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Highlighted word</label>
                                    <InputText v-model="form.about_highlight[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Inspires" />
                                    <p class="text-xs text-slate-400 mt-1">The word within Title to show in orange — must match exactly.</p>
                                    <p v-if="form.errors[`about_highlight.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_highlight.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
                                    <Textarea v-model="form.about_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`about_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_description.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Quote</label>
                                    <Textarea v-model="form.about_quote[activeLang]" :dir="currentLang?.direction" rows="2" class="w-full" />
                                    <p v-if="form.errors[`about_quote.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_quote.${activeLang}`] }}</p>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button text</label>
                                        <InputText v-model="form.about_button_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Discover More" />
                                        <p v-if="form.errors[`about_button_text.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_button_text.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button link</label>
                                        <InputText v-model="form.about_button_url" class="w-full" placeholder="https://... or #" />
                                        <p v-if="form.errors.about_button_url" class="text-xs text-red-500 mt-1">{{ form.errors.about_button_url }}</p>
                                    </div>
                                </div>
                                <p class="text-xs text-slate-400">The "Call Now" number reuses the phone set under General → Header.</p>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Experience badge</h3>
                            <div class="flex flex-col sm:flex-row sm:items-start gap-4">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Icon</label>
                                    <IconPicker v-model="form.about_badge_icon" />
                                    <p v-if="form.errors['about_badge_icon.value']" class="text-xs text-red-500 mt-1">{{ form.errors['about_badge_icon.value'] }}</p>
                                </div>
                                <div class="flex-1 max-w-sm">
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Text</label>
                                    <InputText v-model="form.about_badge_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. 30 Years Of Quality Service" />
                                    <p v-if="form.errors[`about_badge_text.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_badge_text.${activeLang}`] }}</p>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Photos</h3>
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Photo 1</label>
                                    <ImageDropzone
                                        :preview-url="aboutImage1Preview"
                                        hint="Large portrait photo"
                                        width-class="w-full" height-class="h-40"
                                        @select="(file) => onAboutImageSelected('about_image_1', aboutImage1Preview, file)"
                                        @remove="() => onAboutImageRemoved('about_image_1', aboutImage1Preview)"
                                    />
                                    <p v-if="form.errors.about_image_1" class="text-xs text-red-500 mt-1">{{ form.errors.about_image_1 }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Photo 2</label>
                                    <ImageDropzone
                                        :preview-url="aboutImage2Preview"
                                        hint="Top-right photo"
                                        width-class="w-full" height-class="h-40"
                                        @select="(file) => onAboutImageSelected('about_image_2', aboutImage2Preview, file)"
                                        @remove="() => onAboutImageRemoved('about_image_2', aboutImage2Preview)"
                                    />
                                    <p v-if="form.errors.about_image_2" class="text-xs text-red-500 mt-1">{{ form.errors.about_image_2 }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Photo 3</label>
                                    <ImageDropzone
                                        :preview-url="aboutImage3Preview"
                                        hint="Bottom-right photo"
                                        width-class="w-full" height-class="h-40"
                                        @select="(file) => onAboutImageSelected('about_image_3', aboutImage3Preview, file)"
                                        @remove="() => onAboutImageRemoved('about_image_3', aboutImage3Preview)"
                                    />
                                    <p v-if="form.errors.about_image_3" class="text-xs text-red-500 mt-1">{{ form.errors.about_image_3 }}</p>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-3">
                                <h3 class="text-sm font-semibold text-slate-800">Feature items</h3>
                                <Button label="Add item" icon="pi pi-plus" text size="small" @click="addAboutItem" />
                            </div>

                            <p v-if="!form.about_items.length" class="text-sm text-slate-400">No items yet — add one above.</p>
                            <div v-else class="flex flex-col gap-3">
                                <div
                                    v-for="(item, index) in form.about_items"
                                    :key="index"
                                    class="grid grid-cols-1 sm:grid-cols-[auto_1fr_1fr_auto] gap-3 sm:items-start rounded-lg border border-slate-100 p-3"
                                >
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Icon</label>
                                        <IconPicker v-model="item.icon" />
                                        <p v-if="form.errors[`about_items.${index}.icon.value`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_items.${index}.icon.value`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Title</label>
                                        <InputText
                                            v-model="item.title[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required, e.g. International Hubs' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`about_items.${index}.title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_items.${index}.title.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
                                        <InputText
                                            v-model="item.description[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`about_items.${index}.description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_items.${index}.description.${activeLang}`] }}</p>
                                    </div>
                                    <div class="flex sm:justify-end sm:pt-6">
                                        <Button icon="pi pi-trash" text severity="danger" aria-label="Remove item" @click="removeAboutItem(index)" />
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">About Page — Breadcrumb &amp; SEO</h3>
                            <p class="text-xs text-slate-400 mb-4">Shown on the dedicated <code>/about</code> page — separate from the "About Us" homepage block above.</p>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb background image</label>
                                    <ImageDropzone
                                        :preview-url="aboutPageBreadcrumbPreview"
                                        hint="Shown behind the page title"
                                        width-class="w-full sm:w-80" height-class="h-32"
                                        @select="(file) => onAboutImageSelected('about_page_breadcrumb_image', aboutPageBreadcrumbPreview, file)"
                                        @remove="() => onAboutImageRemoved('about_page_breadcrumb_image', aboutPageBreadcrumbPreview)"
                                    />
                                    <p v-if="form.errors.about_page_breadcrumb_image" class="text-xs text-red-500 mt-1">{{ form.errors.about_page_breadcrumb_image }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb title</label>
                                    <InputText v-model="form.about_page_breadcrumb_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. About Us" />
                                    <p v-if="form.errors[`about_page_breadcrumb_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_page_breadcrumb_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta title</label>
                                    <InputText v-model="form.about_page_seo_title[activeLang]" :dir="currentLang?.direction" class="w-full" />
                                    <p v-if="form.errors[`about_page_seo_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_page_seo_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta description</label>
                                    <Textarea v-model="form.about_page_seo_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`about_page_seo_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_page_seo_description.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta keywords</label>
                                    <InputText v-model="form.about_page_seo_keywords[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="comma, separated, keywords" />
                                    <p v-if="form.errors[`about_page_seo_keywords.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`about_page_seo_keywords.${activeLang}`] }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Our Skills -->
                    <div v-show="activeSectionKey === 'skill'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Enrollment card</h3>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Title</label>
                                    <InputText v-model="form.skill_enroll_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Start Your Enrollment" />
                                    <p v-if="form.errors[`skill_enroll_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`skill_enroll_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Subtitle</label>
                                    <InputText v-model="form.skill_enroll_subtitle[activeLang]" :dir="currentLang?.direction" class="w-full" />
                                    <p v-if="form.errors[`skill_enroll_subtitle.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`skill_enroll_subtitle.${activeLang}`] }}</p>
                                </div>
                                <p class="text-xs text-slate-400">The form fields below it (name, email, course, message) are fixed theme UI, not editable here.</p>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Content</h3>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Tagline</label>
                                    <InputText v-model="form.skill_tagline[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Our Skills" />
                                    <p v-if="form.errors[`skill_tagline.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`skill_tagline.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Title</label>
                                    <InputText v-model="form.skill_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Explore Your Creativity And Talent With Us" />
                                    <p v-if="form.errors[`skill_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`skill_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Highlighted words</label>
                                    <InputText v-model="form.skill_highlight[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Creativity And Talent" />
                                    <p class="text-xs text-slate-400 mt-1">The words within Title to show in orange — must match exactly.</p>
                                    <p v-if="form.errors[`skill_highlight.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`skill_highlight.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
                                    <Textarea v-model="form.skill_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`skill_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`skill_description.${activeLang}`] }}</p>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button text</label>
                                        <InputText v-model="form.skill_button_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Learn More" />
                                        <p v-if="form.errors[`skill_button_text.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`skill_button_text.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button link</label>
                                        <InputText v-model="form.skill_button_url" class="w-full" placeholder="https://... or #" />
                                        <p v-if="form.errors.skill_button_url" class="text-xs text-red-500 mt-1">{{ form.errors.skill_button_url }}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <div class="flex items-center justify-between mb-3">
                                <h3 class="text-sm font-semibold text-slate-800">Skill bars</h3>
                                <Button label="Add item" icon="pi pi-plus" text size="small" @click="addSkillItem" />
                            </div>

                            <p v-if="!form.skill_items.length" class="text-sm text-slate-400">No items yet — add one above.</p>
                            <div v-else class="flex flex-col gap-3">
                                <div
                                    v-for="(item, index) in form.skill_items"
                                    :key="index"
                                    class="grid grid-cols-1 sm:grid-cols-[1fr_auto_auto] gap-3 sm:items-start rounded-lg border border-slate-100 p-3"
                                >
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Label</label>
                                        <InputText
                                            v-model="item.label[activeLang]"
                                            :dir="currentLang?.direction"
                                            class="w-full"
                                            :placeholder="currentLang?.is_default ? 'Required, e.g. Our Students' : 'Optional'"
                                        />
                                        <p v-if="form.errors[`skill_items.${index}.label.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`skill_items.${index}.label.${activeLang}`] }}</p>
                                    </div>
                                    <div class="sm:w-24">
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Percent</label>
                                        <InputText v-model="item.percentage" class="w-full" placeholder="85" />
                                        <p v-if="form.errors[`skill_items.${index}.percentage`]" class="text-xs text-red-500 mt-1">{{ form.errors[`skill_items.${index}.percentage`] }}</p>
                                    </div>
                                    <div class="flex sm:justify-end sm:pt-6">
                                        <Button icon="pi pi-trash" text severity="danger" aria-label="Remove item" @click="removeSkillItem(index)" />
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Video Section -->
                    <div v-show="activeSectionKey === 'video'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Content</h3>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Tagline</label>
                                    <InputText v-model="form.video_tagline[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Latest Video" />
                                    <p v-if="form.errors[`video_tagline.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`video_tagline.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Title</label>
                                    <InputText v-model="form.video_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Let's Check Our Latest Video" />
                                    <p v-if="form.errors[`video_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`video_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Highlighted word</label>
                                    <InputText v-model="form.video_highlight[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Latest" />
                                    <p class="text-xs text-slate-400 mt-1">The word within Title to show in orange — must match exactly.</p>
                                    <p v-if="form.errors[`video_highlight.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`video_highlight.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
                                    <Textarea v-model="form.video_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`video_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`video_description.${activeLang}`] }}</p>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button text</label>
                                        <InputText v-model="form.video_button_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Learn More" />
                                        <p v-if="form.errors[`video_button_text.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`video_button_text.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button link</label>
                                        <InputText v-model="form.video_button_url" class="w-full" placeholder="https://... or #" />
                                        <p v-if="form.errors.video_button_url" class="text-xs text-red-500 mt-1">{{ form.errors.video_button_url }}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Video</h3>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Thumbnail</label>
                                    <ImageDropzone
                                        :preview-url="videoThumbnailPreview"
                                        hint="Background image behind the play button"
                                        width-class="w-full" height-class="h-32"
                                        @select="onVideoThumbnailSelected"
                                        @remove="onVideoThumbnailRemoved"
                                    />
                                    <p v-if="form.errors.video_thumbnail" class="text-xs text-red-500 mt-1">{{ form.errors.video_thumbnail }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">YouTube URL</label>
                                    <InputText v-model="form.video_youtube_url" class="w-full" placeholder="https://www.youtube.com/watch?v=..." />
                                    <p v-if="form.errors.video_youtube_url" class="text-xs text-red-500 mt-1">{{ form.errors.video_youtube_url }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Offer Banner -->
                    <div v-show="activeSectionKey === 'offer'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Content</h3>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Title</label>
                                    <InputText v-model="form.offer_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Our 20% Offer Running - Join Today For Your Course" />
                                    <p v-if="form.errors[`offer_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`offer_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Description</label>
                                    <Textarea v-model="form.offer_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`offer_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`offer_description.${activeLang}`] }}</p>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button text</label>
                                        <InputText v-model="form.offer_button_text[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Apply Now" />
                                        <p v-if="form.errors[`offer_button_text.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`offer_button_text.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Button link</label>
                                        <InputText v-model="form.offer_button_url" class="w-full" placeholder="https://... or #" />
                                        <p v-if="form.errors.offer_button_url" class="text-xs text-red-500 mt-1">{{ form.errors.offer_button_url }}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Background image</h3>
                            <div class="max-w-xs">
                                <ImageDropzone
                                    :preview-url="offerBackgroundPreview"
                                    hint="Full-width photo behind the banner"
                                    width-class="w-full" height-class="h-32"
                                    @select="onOfferBackgroundSelected"
                                    @remove="onOfferBackgroundRemoved"
                                />
                                <p v-if="form.errors.offer_background" class="text-xs text-red-500 mt-1">{{ form.errors.offer_background }}</p>
                            </div>
                        </section>
                    </div>

                    <!-- Our Principal -->
                    <div v-show="activeSectionKey === 'principal'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Profile</h3>
                            <div class="flex flex-col sm:flex-row gap-6">
                                <div class="w-full sm:w-48 shrink-0">
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Photo</label>
                                    <ImageDropzone
                                        :preview-url="principalPhotoPreview"
                                        hint="Portrait photo"
                                        width-class="w-full" height-class="h-40"
                                        @select="(file) => onAboutImageSelected('principal_photo', principalPhotoPreview, file)"
                                        @remove="() => onAboutImageRemoved('principal_photo', principalPhotoPreview)"
                                    />
                                    <p v-if="form.errors.principal_photo" class="text-xs text-red-500 mt-1">{{ form.errors.principal_photo }}</p>
                                </div>
                                <div class="flex-1 flex flex-col gap-4 max-w-lg">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Name</label>
                                        <InputText v-model="form.principal_name[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Mohammad Rafiqul Islam" />
                                        <p v-if="form.errors[`principal_name.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`principal_name.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Designation</label>
                                        <InputText v-model="form.principal_designation[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Principal" />
                                        <p v-if="form.errors[`principal_designation.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`principal_designation.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Message</label>
                                        <Textarea v-model="form.principal_message[activeLang]" :dir="currentLang?.direction" rows="6" class="w-full" placeholder="Principal's message to visitors..." />
                                        <p v-if="form.errors[`principal_message.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`principal_message.${activeLang}`] }}</p>
                                    </div>
                                    <p class="text-xs text-slate-400">Contact details shown on the page reuse the address/phone/email set under General → Header.</p>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Page — Breadcrumb &amp; SEO</h3>
                            <p class="text-xs text-slate-400 mb-4">Shown on the dedicated <code>/principal</code> page.</p>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb background image</label>
                                    <ImageDropzone
                                        :preview-url="principalPageBreadcrumbPreview"
                                        hint="Shown behind the page title"
                                        width-class="w-full sm:w-80" height-class="h-32"
                                        @select="(file) => onAboutImageSelected('principal_page_breadcrumb_image', principalPageBreadcrumbPreview, file)"
                                        @remove="() => onAboutImageRemoved('principal_page_breadcrumb_image', principalPageBreadcrumbPreview)"
                                    />
                                    <p v-if="form.errors.principal_page_breadcrumb_image" class="text-xs text-red-500 mt-1">{{ form.errors.principal_page_breadcrumb_image }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb title</label>
                                    <InputText v-model="form.principal_page_breadcrumb_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Our Principal" />
                                    <p v-if="form.errors[`principal_page_breadcrumb_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`principal_page_breadcrumb_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta title</label>
                                    <InputText v-model="form.principal_page_seo_title[activeLang]" :dir="currentLang?.direction" class="w-full" />
                                    <p v-if="form.errors[`principal_page_seo_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`principal_page_seo_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta description</label>
                                    <Textarea v-model="form.principal_page_seo_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`principal_page_seo_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`principal_page_seo_description.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta keywords</label>
                                    <InputText v-model="form.principal_page_seo_keywords[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="comma, separated, keywords" />
                                    <p v-if="form.errors[`principal_page_seo_keywords.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`principal_page_seo_keywords.${activeLang}`] }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Ex-Principal -->
                    <div v-show="activeSectionKey === 'ex-principal'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Profile</h3>
                            <div class="flex flex-col sm:flex-row gap-6">
                                <div class="w-full sm:w-48 shrink-0">
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Photo</label>
                                    <ImageDropzone
                                        :preview-url="exPrincipalPhotoPreview"
                                        hint="Portrait photo"
                                        width-class="w-full" height-class="h-40"
                                        @select="(file) => onAboutImageSelected('ex_principal_photo', exPrincipalPhotoPreview, file)"
                                        @remove="() => onAboutImageRemoved('ex_principal_photo', exPrincipalPhotoPreview)"
                                    />
                                    <p v-if="form.errors.ex_principal_photo" class="text-xs text-red-500 mt-1">{{ form.errors.ex_principal_photo }}</p>
                                </div>
                                <div class="flex-1 flex flex-col gap-4 max-w-lg">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Name</label>
                                        <InputText v-model="form.ex_principal_name[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Abdul Hamid Chowdhury" />
                                        <p v-if="form.errors[`ex_principal_name.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`ex_principal_name.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Designation</label>
                                        <InputText v-model="form.ex_principal_designation[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Former Principal" />
                                        <p v-if="form.errors[`ex_principal_designation.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`ex_principal_designation.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Message</label>
                                        <Textarea v-model="form.ex_principal_message[activeLang]" :dir="currentLang?.direction" rows="6" class="w-full" placeholder="A message from the former principal..." />
                                        <p v-if="form.errors[`ex_principal_message.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`ex_principal_message.${activeLang}`] }}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Page — Breadcrumb &amp; SEO</h3>
                            <p class="text-xs text-slate-400 mb-4">Shown on the dedicated <code>/ex-principals</code> page.</p>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb background image</label>
                                    <ImageDropzone
                                        :preview-url="exPrincipalPageBreadcrumbPreview"
                                        hint="Shown behind the page title"
                                        width-class="w-full sm:w-80" height-class="h-32"
                                        @select="(file) => onAboutImageSelected('ex_principal_page_breadcrumb_image', exPrincipalPageBreadcrumbPreview, file)"
                                        @remove="() => onAboutImageRemoved('ex_principal_page_breadcrumb_image', exPrincipalPageBreadcrumbPreview)"
                                    />
                                    <p v-if="form.errors.ex_principal_page_breadcrumb_image" class="text-xs text-red-500 mt-1">{{ form.errors.ex_principal_page_breadcrumb_image }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb title</label>
                                    <InputText v-model="form.ex_principal_page_breadcrumb_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Our EX Principal" />
                                    <p v-if="form.errors[`ex_principal_page_breadcrumb_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`ex_principal_page_breadcrumb_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta title</label>
                                    <InputText v-model="form.ex_principal_page_seo_title[activeLang]" :dir="currentLang?.direction" class="w-full" />
                                    <p v-if="form.errors[`ex_principal_page_seo_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`ex_principal_page_seo_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta description</label>
                                    <Textarea v-model="form.ex_principal_page_seo_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`ex_principal_page_seo_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`ex_principal_page_seo_description.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta keywords</label>
                                    <InputText v-model="form.ex_principal_page_seo_keywords[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="comma, separated, keywords" />
                                    <p v-if="form.errors[`ex_principal_page_seo_keywords.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`ex_principal_page_seo_keywords.${activeLang}`] }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Contact Page -->
                    <div v-show="activeSectionKey === 'contact'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Office info cards</h3>
                            <p class="text-xs text-slate-400 mb-4">Dedicated to this page — both the card's label (e.g. "Office Address") and its value are per-language, so wording can differ by language rather than just being translated.</p>
                            <div class="flex flex-col gap-5">
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Address — Label</label>
                                        <InputText v-model="form.contact_address_label[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Office Address" />
                                        <p v-if="form.errors[`contact_address_label.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_address_label.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Address — Value</label>
                                        <InputText v-model="form.contact_address_value[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="City, Country" />
                                        <p v-if="form.errors[`contact_address_value.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_address_value.${activeLang}`] }}</p>
                                    </div>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Phone — Label</label>
                                        <InputText v-model="form.contact_phone_label[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Call Us" />
                                        <p v-if="form.errors[`contact_phone_label.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_phone_label.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Phone — Value</label>
                                        <InputText v-model="form.contact_phone_value[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="+880 1712-345678" />
                                        <p v-if="form.errors[`contact_phone_value.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_phone_value.${activeLang}`] }}</p>
                                    </div>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Email — Label</label>
                                        <InputText v-model="form.contact_email_label[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Email Us" />
                                        <p v-if="form.errors[`contact_email_label.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_email_label.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Email — Value</label>
                                        <InputText v-model="form.contact_email_value[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="info@example.com" />
                                        <p v-if="form.errors[`contact_email_value.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_email_value.${activeLang}`] }}</p>
                                    </div>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Open Time — Label</label>
                                        <InputText v-model="form.contact_open_time_label[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Open Time" />
                                        <p v-if="form.errors[`contact_open_time_label.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_open_time_label.${activeLang}`] }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-slate-600 mb-1.5">Open Time — Value</label>
                                        <InputText v-model="form.contact_open_time[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Mon - Sat (10.00AM - 05.30PM)" />
                                        <p v-if="form.errors[`contact_open_time.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_open_time.${activeLang}`] }}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Content</h3>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Form title</label>
                                    <InputText v-model="form.contact_form_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Get In Touch" />
                                    <p v-if="form.errors[`contact_form_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_form_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Form description</label>
                                    <Textarea v-model="form.contact_form_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`contact_form_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_form_description.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Side image</label>
                                    <ImageDropzone
                                        :preview-url="contactImagePreview"
                                        hint="Shown beside the form"
                                        width-class="w-full sm:w-80" height-class="h-40"
                                        @select="(file) => onAboutImageSelected('contact_image', contactImagePreview, file)"
                                        @remove="() => onAboutImageRemoved('contact_image', contactImagePreview)"
                                    />
                                    <p v-if="form.errors.contact_image" class="text-xs text-red-500 mt-1">{{ form.errors.contact_image }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Map embed URL</label>
                                    <InputText v-model="form.contact_map_embed_url" class="w-full" placeholder="https://www.google.com/maps?q=...&output=embed" />
                                    <p class="text-xs text-slate-400 mt-1">The <code>src</code> of a Google Maps embed iframe — open Google Maps, Share → Embed a map, copy the URL inside <code>src="..."</code>.</p>
                                    <p v-if="form.errors.contact_map_embed_url" class="text-xs text-red-500 mt-1">{{ form.errors.contact_map_embed_url }}</p>
                                </div>
                            </div>
                        </section>

                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Page — Breadcrumb &amp; SEO</h3>
                            <p class="text-xs text-slate-400 mb-4">Shown on the dedicated <code>/contact</code> page.</p>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb background image</label>
                                    <ImageDropzone
                                        :preview-url="contactPageBreadcrumbPreview"
                                        hint="Shown behind the page title"
                                        width-class="w-full sm:w-80" height-class="h-32"
                                        @select="(file) => onAboutImageSelected('contact_page_breadcrumb_image', contactPageBreadcrumbPreview, file)"
                                        @remove="() => onAboutImageRemoved('contact_page_breadcrumb_image', contactPageBreadcrumbPreview)"
                                    />
                                    <p v-if="form.errors.contact_page_breadcrumb_image" class="text-xs text-red-500 mt-1">{{ form.errors.contact_page_breadcrumb_image }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb title</label>
                                    <InputText v-model="form.contact_page_breadcrumb_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Contact Us" />
                                    <p v-if="form.errors[`contact_page_breadcrumb_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_page_breadcrumb_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta title</label>
                                    <InputText v-model="form.contact_page_seo_title[activeLang]" :dir="currentLang?.direction" class="w-full" />
                                    <p v-if="form.errors[`contact_page_seo_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_page_seo_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta description</label>
                                    <Textarea v-model="form.contact_page_seo_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`contact_page_seo_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_page_seo_description.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta keywords</label>
                                    <InputText v-model="form.contact_page_seo_keywords[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="comma, separated, keywords" />
                                    <p v-if="form.errors[`contact_page_seo_keywords.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`contact_page_seo_keywords.${activeLang}`] }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Student List Page -->
                    <div v-show="activeSectionKey === 'student-list'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Page — Breadcrumb &amp; SEO</h3>
                            <p class="text-xs text-slate-400 mb-4">Shown on the dedicated <code>/students</code> page.</p>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb background image</label>
                                    <ImageDropzone
                                        :preview-url="studentListPageBreadcrumbPreview"
                                        hint="Shown behind the page title"
                                        width-class="w-full sm:w-80" height-class="h-32"
                                        @select="(file) => onImageSelected('student_list_page_breadcrumb_image', studentListPageBreadcrumbPreview, file)"
                                        @remove="() => onImageRemoved('student_list_page_breadcrumb_image', studentListPageBreadcrumbPreview)"
                                    />
                                    <p v-if="form.errors.student_list_page_breadcrumb_image" class="text-xs text-red-500 mt-1">{{ form.errors.student_list_page_breadcrumb_image }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb title</label>
                                    <InputText v-model="form.student_list_page_breadcrumb_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Student List" />
                                    <p v-if="form.errors[`student_list_page_breadcrumb_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`student_list_page_breadcrumb_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta title</label>
                                    <InputText v-model="form.student_list_page_seo_title[activeLang]" :dir="currentLang?.direction" class="w-full" />
                                    <p v-if="form.errors[`student_list_page_seo_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`student_list_page_seo_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta description</label>
                                    <Textarea v-model="form.student_list_page_seo_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`student_list_page_seo_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`student_list_page_seo_description.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta keywords</label>
                                    <InputText v-model="form.student_list_page_seo_keywords[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="comma, separated, keywords" />
                                    <p v-if="form.errors[`student_list_page_seo_keywords.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`student_list_page_seo_keywords.${activeLang}`] }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Tuition Fees Page -->
                    <div v-show="activeSectionKey === 'tuition-fees'" class="flex flex-col gap-5">
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Page — Breadcrumb &amp; SEO</h3>
                            <p class="text-xs text-slate-400 mb-4">Shown on the dedicated <code>/tuition-fees</code> page.</p>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb background image</label>
                                    <ImageDropzone
                                        :preview-url="tuitionFeePageBreadcrumbPreview"
                                        hint="Shown behind the page title"
                                        width-class="w-full sm:w-80" height-class="h-32"
                                        @select="(file) => onImageSelected('tuition_fee_page_breadcrumb_image', tuitionFeePageBreadcrumbPreview, file)"
                                        @remove="() => onImageRemoved('tuition_fee_page_breadcrumb_image', tuitionFeePageBreadcrumbPreview)"
                                    />
                                    <p v-if="form.errors.tuition_fee_page_breadcrumb_image" class="text-xs text-red-500 mt-1">{{ form.errors.tuition_fee_page_breadcrumb_image }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb title</label>
                                    <InputText v-model="form.tuition_fee_page_breadcrumb_title[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="e.g. Tuition Fees" />
                                    <p v-if="form.errors[`tuition_fee_page_breadcrumb_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`tuition_fee_page_breadcrumb_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta title</label>
                                    <InputText v-model="form.tuition_fee_page_seo_title[activeLang]" :dir="currentLang?.direction" class="w-full" />
                                    <p v-if="form.errors[`tuition_fee_page_seo_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`tuition_fee_page_seo_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta description</label>
                                    <Textarea v-model="form.tuition_fee_page_seo_description[activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`tuition_fee_page_seo_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`tuition_fee_page_seo_description.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta keywords</label>
                                    <InputText v-model="form.tuition_fee_page_seo_keywords[activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="comma, separated, keywords" />
                                    <p v-if="form.errors[`tuition_fee_page_seo_keywords.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`tuition_fee_page_seo_keywords.${activeLang}`] }}</p>
                                </div>
                            </div>
                        </section>
                        <section class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">Tuition Fee Page Content</h3>
                            <p class="text-xs text-slate-400 mb-4">Edit the text and tables that appear on the tuition fees page.</p>
                            <Editor v-model="form.tuition_fee_page_content[activeLang]" :editor-style="`height: 350px; direction: ${currentLang?.direction ?? 'ltr'};`" />
                            <p v-if="form.errors[`tuition_fee_page_content.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`tuition_fee_page_content.${activeLang}`] }}</p>
                        </section>
                    </div>

                    <!-- Result Pages -->
                    <div v-show="activeSectionKey === 'results'" class="flex flex-col gap-5">
                        <section v-for="page in [
                            { key: 'exam_result', label: 'Exam Result Page' },
                            { key: 'academic_result', label: 'Academic Result Page' },
                            { key: 'evaluation_result', label: 'Evaluation Result Page' },
                            { key: 'board_exam_result', label: 'Board Exam Result Page' }
                        ]" :key="page.key" class="rounded-xl border border-slate-200 p-5">
                            <h3 class="text-sm font-semibold text-slate-800 mb-3">{{ page.label }} — Breadcrumb &amp; SEO</h3>
                            <div class="flex flex-col gap-4 max-w-lg">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb background image</label>
                                    <ImageDropzone
                                        :preview-url="page.key === 'exam_result' ? examResultPageBreadcrumbPreview : page.key === 'academic_result' ? academicResultPageBreadcrumbPreview : page.key === 'evaluation_result' ? evaluationResultPageBreadcrumbPreview : boardExamResultPageBreadcrumbPreview"
                                        hint="Shown behind the page title"
                                        width-class="w-full sm:w-80" height-class="h-32"
                                        @select="(file) => onImageSelected(`${page.key}_page_breadcrumb_image`, page.key === 'exam_result' ? examResultPageBreadcrumbPreview : page.key === 'academic_result' ? academicResultPageBreadcrumbPreview : page.key === 'evaluation_result' ? evaluationResultPageBreadcrumbPreview : boardExamResultPageBreadcrumbPreview, file)"
                                        @remove="() => onImageRemoved(`${page.key}_page_breadcrumb_image`, page.key === 'exam_result' ? examResultPageBreadcrumbPreview : page.key === 'academic_result' ? academicResultPageBreadcrumbPreview : page.key === 'evaluation_result' ? evaluationResultPageBreadcrumbPreview : boardExamResultPageBreadcrumbPreview)"
                                    />
                                    <p v-if="form.errors[`${page.key}_page_breadcrumb_image`]" class="text-xs text-red-500 mt-1">{{ form.errors[`${page.key}_page_breadcrumb_image`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Breadcrumb title</label>
                                    <InputText v-model="form[`${page.key}_page_breadcrumb_title`][activeLang]" :dir="currentLang?.direction" class="w-full" :placeholder="`e.g. ${page.label}`" />
                                    <p v-if="form.errors[`${page.key}_page_breadcrumb_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`${page.key}_page_breadcrumb_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta title</label>
                                    <InputText v-model="form[`${page.key}_page_seo_title`][activeLang]" :dir="currentLang?.direction" class="w-full" />
                                    <p v-if="form.errors[`${page.key}_page_seo_title.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`${page.key}_page_seo_title.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta description</label>
                                    <Textarea v-model="form[`${page.key}_page_seo_description`][activeLang]" :dir="currentLang?.direction" rows="3" class="w-full" />
                                    <p v-if="form.errors[`${page.key}_page_seo_description.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`${page.key}_page_seo_description.${activeLang}`] }}</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Meta keywords</label>
                                    <InputText v-model="form[`${page.key}_page_seo_keywords`][activeLang]" :dir="currentLang?.direction" class="w-full" placeholder="comma, separated, keywords" />
                                    <p v-if="form.errors[`${page.key}_page_seo_keywords.${activeLang}`]" class="text-xs text-red-500 mt-1">{{ form.errors[`${page.key}_page_seo_keywords.${activeLang}`] }}</p>
                                </div>
                            </div>
                        </section>
                    </div>

                    <div class="mt-8 pt-5 border-t border-slate-200 flex justify-end">
                        <Button label="Save Changes" icon="pi pi-check" :loading="form.processing" @click="submit" />
                    </div>
                </template>
            </Card>
        </div>
    </AdminLayout>
</template>

