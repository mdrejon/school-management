<?php

return [
    'name' => 'Exam',
];
