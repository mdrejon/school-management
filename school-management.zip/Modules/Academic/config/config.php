<?php

return [
    'name' => 'Academic',
];
