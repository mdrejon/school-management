<?php

return [
    'name' => 'Teacher',
];
